import React from 'react';
import CampaignForm from './Components/CampaignForm';
import CampaignList from './Components/CampaignList';

function App() {
  return (
    <div className="p-4 max-w-4xl mx-auto bg-gray-100 min-h-screen">
      <h1 className="text-3xl font-bold mb-4 text-black">CrowdTrust AI</h1>
      <CampaignForm />
      <CampaignList />
    </div>
  );
}

export default App;