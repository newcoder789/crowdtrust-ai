import React, { useState } from 'react';
import axios from 'axios';

function CampaignForm() {
  const [formData, setFormData] = useState({
    name: '',
    description: '',
    detail: '',
    owner: '0xDefaultOwner',
    contractAddress: '0xDefaultContract',
    goal: '',
  });
  const [uiImage, setUiImage] = useState(null);
  const [aiCheckImage, setAiCheckImage] = useState(null);

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleFileChange = (e) => {
    if (e.target.name === 'uiImage') setUiImage(e.target.files[0]);
    if (e.target.name === 'aiCheckImage') setAiCheckImage(e.target.files[0]);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const data = new FormData();
    for (let key in formData) data.append(key, formData[key]);
    if (uiImage) data.append('uiImage', uiImage);
    if (aiCheckImage) data.append('aiCheckImage', aiCheckImage);

    try {
      await axios.post('http://localhost:5000/analyze', data);
      setFormData({ name: '', description: '', detail: '', owner: '0xDefaultOwner', contractAddress: '0xDefaultContract', goal: '' });
      setUiImage(null);
      setAiCheckImage(null);
      window.location.reload();
    } catch (err) {
      console.error(err);
    }
  };

  return (
    <div className="bg-white p-4 rounded shadow mb-4">
      <h2 className="text-xl font-semibold mb-2">Create Campaign</h2>
      <form onSubmit={handleSubmit} className="space-y-2">
        <input name="name" value={formData.name} onChange={handleChange} placeholder="Name" className="w-full p-2 border rounded" />
        <input name="description" value={formData.description} onChange={handleChange} placeholder="Description" className="w-full p-2 border rounded" />
        <input name="detail" value={formData.detail} onChange={handleChange} placeholder="Detail" className="w-full p-2 border rounded" />
        <input name="goal" type="number" value={formData.goal} onChange={handleChange} placeholder="Goal (ETH)" className="w-full p-2 border rounded" />
        <input name="uiImage" type="file" onChange={handleFileChange} className="w-full" />
        <input name="aiCheckImage" type="file" onChange={handleFileChange} className="w-full" />
        <button type="submit" className="bg-blue-500 text-white px-4 py-2 rounded">Submit</button>
      </form>
    </div>
  );
}

export default CampaignForm;